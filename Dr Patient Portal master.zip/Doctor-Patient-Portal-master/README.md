# Doctor-Patient-Portal
This is a database Portal having Doctor and Patient Doctor can add Patient.Almost Doctor Portal is complete and Patient Portal don't have any functionality.

Requirements
flask
pymongo
Pycharm IDE recommended (Optional)
you can download pycharm from here.
https://www.jetbrains.com/pycharm/download/
Python as a Programming language.
MongoDB as Database
